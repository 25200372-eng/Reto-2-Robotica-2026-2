# arm_broker — RB-2 «El Turno del Brazo» (Ítem 2)

Único nodo que publica en `/joint_states`. Los clientes piden turno por la acción `/arm/move_joints`.

## Paquetes
- `arm_broker_interfaces`: acción `MoveJoints` y mensaje `QueueState`.
- `arm_broker`: `broker_node` (servidor), `demo_client`, `admission.py` (portero con FK), `policies.py` (FIFO, prioridad, envejecimiento, round-robin), `kinematics.py` (FK del Ítem 1, copia sin cambios; el portero usa `fk(q_rad) -> T 4x4 en mm`).

## Compilar y ejecutar (en el Jetson, terminal de JupyterLab)
```bash
export ROS_DOMAIN_ID=<42 + n.º de equipo>
export ROS_LOCALHOST_ONLY=0
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
# + ROS_DISCOVERY_SERVER / FASTRTPS_DEFAULT_PROFILES_FILE según la guía del reto
cd ~/ws && colcon build --packages-select arm_broker_interfaces arm_broker
source install/setup.bash

ros2 run arm_broker arm_broker --ros-args -p policy:=aging -p log_dir:=$HOME/rb2_logs
# otras políticas: fifo | priority | aging | rr
```
Cada integrante, desde su máquina: `ros2 run arm_broker demo_client --client ana --priority 1 --n 5`
(o desde un notebook: ver docstring de `demo_client.py`). `ros2 topic echo /arm/queue_state` para ver la cola.

## Convenciones
- `q` en **radianes** (el SDK `pymycobot` usa grados: convertir si hace falta). Prioridad: 0 = más alta, 2 = más baja.
- Rechazos: `GoalResponse.REJECT` no puede llevar texto en ROS 2, por eso el motivo va a **`/arm/rejections`**, al log y a `rechazos.csv` (códigos `JOINT_LIMIT`, `WORKSPACE`, `STEP_TOO_LARGE`, `BAD_LENGTH`, `NOT_FINITE`, `NO_CLIENT`, `QUEUE_FULL`).
- `goals_log.csv`: espera y duración por goal (sirve para el Ítem 3: media, p95, Jain).
- Revisar nombres de joints (`joint_names`), límites y workspace (`r_max_mm`, `z_min_mm`) con su robot.

## Diagrama de secuencia
```mermaid
sequenceDiagram
    participant C as Cliente (x4)
    participant S as ActionServer (grupo reentrante)
    participant Q as Cola + política
    participant W as Worker (grupo exclusivo)
    participant J as /joint_states
    C->>S: send_goal(q, prioridad)
    S->>S: goal_callback: validar con FK
    alt inválido
        S-->>C: REJECT (motivo en /arm/rejections + CSV)
    else válido
        S->>Q: handle_accepted_callback: encolar
        S-->>C: ACCEPT
        W->>Q: pop según política
        W->>J: publica trayectoria (único publicador)
        W-->>C: feedback / resultado
    end
    Note over S,Q: /arm/queue_state a 5 Hz
```
