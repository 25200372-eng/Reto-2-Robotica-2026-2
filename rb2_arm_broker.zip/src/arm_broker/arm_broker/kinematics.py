#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kinematics.py — RB-2, Item 1: Cinematica Directa (FK) del JetCobot (myCobot 280)
por Denavit-Hartenberg clasico: T_i = Rot_z(theta_i)*Trans_z(d_i)*Trans_x(a_i)*Rot_x(alpha_i),
con theta_i = q_i + offset_i. Cotas d1,a2,a3,d4,d5 del manual fisico del myCobot 280;
d6 tomado de la doc. oficial de Elephant Robotics y pendiente de verificar en el robot real.
Modulo sin dependencia de ROS/rclpy para poder testearlo e importarlo (Item 2, Item 4)
sin levantar ningun nodo.
"""

import math
from dataclasses import dataclass
from typing import Sequence, Tuple

import numpy as np


@dataclass(frozen=True)
class DHParam:
    """Constantes DH de UNA articulacion (theta NO va aqui: es la variable q_i)."""
    d: float      # desplazamiento a lo largo de z_{i-1}, mm
    a: float      # longitud del eslabon a lo largo de x_i, mm
    alpha: float  # torsion del eslabon, rad
    offset: float  # desfase mecanico motor <-> modelo DH, rad


# Tabla DH del JetCobot (identico mecanicamente al myCobot 280): J1..J6
JETCOBOT_DH = [
    DHParam(134.75, 0.0,    math.pi / 2, 0.0),           # J1: giro de base
    DHParam(0.0,    -110.0, 0.0,        -math.pi / 2),   # J2: hombro
    DHParam(0.0,    -96.0,  0.0,         0.0),           # J3: codo
    DHParam(63.4,   0.0,    math.pi / 2, -math.pi / 2),  # J4: muneca 1
    DHParam(75.05,  0.0,   -math.pi / 2,  math.pi / 2),  # J5: muneca 2
    DHParam(45.6,   0.0,    0.0,          0.0),          # J6: muneca 3 (verificar fisicamente)
]
NUM_JOINTS = len(JETCOBOT_DH)  # = 6, usado para validar la longitud de q


def dh_transform(theta: float, d: float, a: float, alpha: float) -> np.ndarray:
    """Matriz homogenea DH elemental (forma cerrada, ya expandida) para UNA articulacion."""
    ct, st = math.cos(theta), math.sin(theta)
    ca, sa = math.cos(alpha), math.sin(alpha)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0.0,      sa,       ca,      d],
        [0.0,     0.0,      0.0,    1.0],
    ])


def fk(q: Sequence[float]) -> np.ndarray:
    """Cinematica Directa: q (rad, 6 valores) -> T_6^0, pose homogenea del efector final
    respecto a la base. Multiplica en cadena las 6 transformaciones DH elementales."""
    if len(q) != NUM_JOINTS:
        raise ValueError(f"Se esperaban {NUM_JOINTS} angulos, se recibieron {len(q)}.")
    T = np.eye(4)
    for qi, p in zip(q, JETCOBOT_DH):
        T = T @ dh_transform(qi + p.offset, p.d, p.a, p.alpha)  # theta_i = q_i + offset_i
    return T


def fk_pose(q: Sequence[float]) -> Tuple[float, float, float, float, float, float]:
    """Atajo: fk(q) + extraccion de (x,y,z,roll,pitch,yaw) [mm, grados, Euler ZYX],
    en el mismo formato que reporta pymycobot (get_coords/send_coords) para poder
    comparar directamente en la verificacion fisica (Item 1) y en la auditoria (Item 4)."""
    T = fk(q)
    x, y, z = T[0, 3], T[1, 3], T[2, 3]
    R = T[:3, :3]
    sy = math.sqrt(R[0, 0] ** 2 + R[1, 0] ** 2)
    if sy > 1e-6:
        roll = math.atan2(R[2, 1], R[2, 2])
        pitch = math.atan2(-R[2, 0], sy)
        yaw = math.atan2(R[1, 0], R[0, 0])
    else:
        # Gimbal lock (pitch = +-90 grados): roll y yaw quedan acoplados, fijamos yaw=0.
        roll = math.atan2(-R[1, 2], R[1, 1])
        pitch = math.atan2(-R[2, 0], sy)
        yaw = 0.0
    return x, y, z, math.degrees(roll), math.degrees(pitch), math.degrees(yaw)


if __name__ == "__main__":
    # Smoke test rapido: `python3 kinematics.py` (no se ejecuta al hacer `import kinematics`).
    x, y, z, roll, pitch, yaw = fk_pose([0.0] * NUM_JOINTS)
    print(f"q=0 -> x={x:.2f} y={y:.2f} z={z:.2f} mm | roll={roll:.1f} pitch={pitch:.1f} yaw={yaw:.1f} deg")
