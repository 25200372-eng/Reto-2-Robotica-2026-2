"""arm_broker: unico nodo que publica en /joint_states.

  _goal_cb      (grupo reentrante)  portero: valida con la FK, rechaza con motivo
  _accepted_cb  (grupo reentrante)  SOLO encola
  _worker_tick  (grupo exclusivo)   desencola y ejecuta de a uno
"""
import csv
import os
import threading
import time

import numpy as np
import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import String

from arm_broker_interfaces.action import MoveJoints
from arm_broker_interfaces.msg import QueueState

from .admission import Limits, validate
from .policies import Entry, Scheduler

RATE = 20.0  # Hz de /joint_states durante un movimiento
NAMES = ['joint2_to_joint1', 'joint3_to_joint2', 'joint4_to_joint3',
         'joint5_to_joint4', 'joint6_to_joint5', 'joint6output_to_joint6']


class ArmBroker(Node):
    def __init__(self):
        super().__init__('arm_broker')
        for k, v in dict(policy='aging', aging_rate=0.05, max_queue=20, max_joint_vel=0.5,
                         initial_q=[0.0] * 6, joint_names=NAMES, r_max_mm=280.0,
                         z_min_mm=10.0, max_step=1.5, log_dir='.').items():
            self.declare_parameter(k, v)
        p = lambda k: self.get_parameter(k).value  # noqa: E731

        self._sched = Scheduler(p('policy'), p('aging_rate'))
        self._max_queue, self._vmax, self._names = p('max_queue'), p('max_joint_vel'), list(p('joint_names'))
        self._lim = Limits(r_max=p('r_max_mm'), z_min=p('z_min_mm'), max_step=p('max_step'))
        self._cur_q = np.array(p('initial_q'), float)   # pose actual (solo la toca el worker)
        self._ref_q = self._cur_q.copy()                # referencia para "paso excesivo"
        self._lock, self._log_lock = threading.Lock(), threading.Lock()
        self._seq = self._n_acc = self._n_rej = self._n_done = 0
        self._active, self._by_uuid = None, {}

        self._dir = p('log_dir')
        self._log('rechazos.csv', ['t_wall', 'client_id', 'priority', 'codigo', 'motivo'], 'w')
        self._log('goals_log.csv', ['seq', 'client_id', 'priority', 't_enq_wall', 'espera_s',
                                    'duracion_s', 'resultado'], 'w')

        accept_grp, worker_grp = ReentrantCallbackGroup(), MutuallyExclusiveCallbackGroup()
        self._js_pub = self.create_publisher(JointState, '/joint_states', 10)  # UNICO publicador
        self._qs_pub = self.create_publisher(QueueState, '/arm/queue_state', 10)
        self._rej_pub = self.create_publisher(String, '/arm/rejections', 10)
        ActionServer(self, MoveJoints, '/arm/move_joints', execute_callback=self._await_result,
                     goal_callback=self._goal_cb, handle_accepted_callback=self._accepted_cb,
                     cancel_callback=lambda gh: CancelResponse.ACCEPT, callback_group=accept_grp)
        self.create_timer(0.05, self._worker_tick, callback_group=worker_grp)
        self.create_timer(0.2, self._publish_queue_state, callback_group=accept_grp)  # 5 Hz
        self.get_logger().info(f'arm_broker listo | politica={self._sched.policy} | accion=/arm/move_joints')

    # ---- portero ----
    def _goal_cb(self, req):
        with self._lock:
            full, ref = len(self._sched) >= self._max_queue, self._ref_q.copy()
        if not req.client_id:
            return self._reject(req, 'NO_CLIENT', 'client_id vacio')
        if full:
            return self._reject(req, 'QUEUE_FULL', f'cola llena ({self._max_queue})')
        ok, code, msg = validate(list(req.q), ref, self._lim)
        return GoalResponse.ACCEPT if ok else self._reject(req, code, msg)

    def _reject(self, req, code, msg):
        with self._lock:
            self._n_rej += 1
        self.get_logger().warn(f'RECHAZADO [{req.client_id}] {code}: {msg}')
        self._log('rechazos.csv', [f'{time.time():.3f}', req.client_id, req.priority, code, msg])
        self._rej_pub.publish(String(data=f'{req.client_id}|{code}|{msg}'))
        return GoalResponse.REJECT

    # ---- encolado (NO ejecuta) ----
    def _accepted_cb(self, gh):
        r = gh.request
        with self._lock:
            self._seq += 1
            e = Entry(self._seq, r.client_id, int(r.priority), time.monotonic(),
                      [float(x) for x in r.q], t_wall=time.time(), gh=gh)
            self._by_uuid[bytes(gh.goal_id.uuid)] = e
            self._sched.push(e)
            self._ref_q, self._n_acc = np.array(e.q), self._n_acc + 1
        self.get_logger().info(f'encolado #{e.seq} [{e.client_id}] prio={e.priority}')

    # ---- worker unico ----
    def _worker_tick(self):
        with self._lock:
            e = self._active = self._sched.pop(time.monotonic())
        if e is None:
            return
        e.t_start = time.monotonic()
        e.gh.execute()  # dispara _await_result, que solo espera el resultado
        if e.gh.is_cancel_requested:
            e.outcome, e.message = 'canceled', 'cancelado antes de ejecutarse'
        else:
            e.outcome, e.message = self._move_to(e)
        e.final_q = [float(x) for x in self._cur_q]
        with self._lock:
            self._active, self._n_done = None, self._n_done + 1
        self._log('goals_log.csv', [e.seq, e.client_id, e.priority, f'{e.t_wall:.3f}',
                                    f'{e.t_start - e.t_enq:.3f}',
                                    f'{time.monotonic() - e.t_start:.3f}', e.outcome])
        e.done.set()

    def _move_to(self, e):
        q0, q1 = self._cur_q.copy(), np.array(e.q)
        n = max(int(np.abs(q1 - q0).max() / self._vmax * RATE), 2)
        fb = MoveJoints.Feedback(queue_position=0, state='EXECUTING')
        for i in range(1, n + 1):
            if e.gh.is_cancel_requested:
                return 'canceled', 'cancelado durante la ejecucion'
            self._publish_joint_state(q0 + (q1 - q0) * (0.5 - 0.5 * np.cos(np.pi * i / n)))
            fb.progress = i / n
            e.gh.publish_feedback(fb)
            time.sleep(1.0 / RATE)
        return 'succeeded', 'ok'

    def _publish_joint_state(self, q):
        """Unico punto del sistema que escribe en /joint_states."""
        self._cur_q = np.array(q)
        m = JointState(name=self._names, position=[float(x) for x in q])
        m.header.stamp = self.get_clock().now().to_msg()
        self._js_pub.publish(m)

    def _await_result(self, gh):
        """execute_callback: espera al worker y cierra el goal."""
        e = self._by_uuid.pop(bytes(gh.goal_id.uuid), None)
        res = MoveJoints.Result()
        if e is None:
            gh.abort()
            res.message = 'error interno'
            return res
        while not e.done.wait(0.1) and rclpy.ok():
            pass
        if gh.is_cancel_requested:
            gh.canceled()
        elif e.outcome == 'succeeded':
            gh.succeed()
        else:
            gh.abort()
        res.success = e.outcome == 'succeeded' and not gh.is_cancel_requested
        res.message, res.final_q = e.message, e.final_q
        return res

    # ---- /arm/queue_state (5 Hz) ----
    def _publish_queue_state(self):
        now = time.monotonic()
        with self._lock:
            q = sorted((e for e in self._sched.items if not e.gh.is_cancel_requested), key=lambda e: e.seq)
            act, counts = self._active, (self._n_acc, self._n_rej, self._n_done)
        m = QueueState(policy=self._sched.policy, queue_length=len(q),
                       executing_client=act.client_id if act else '',
                       executing_seq=act.seq if act else 0,
                       queued_seq=[e.seq for e in q], queued_clients=[e.client_id for e in q],
                       queued_priorities=[e.priority for e in q],
                       queued_wait_s=[now - e.t_enq for e in q],
                       total_accepted=counts[0], total_rejected=counts[1], total_done=counts[2])
        m.stamp = self.get_clock().now().to_msg()
        self._qs_pub.publish(m)

    def _log(self, name, row, mode='a'):
        with self._log_lock, open(os.path.join(self._dir, name), mode, newline='') as f:
            csv.writer(f).writerow(row)


def main():
    rclpy.init()
    node = ArmBroker()
    ex = MultiThreadedExecutor(num_threads=8)
    ex.add_node(node)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
