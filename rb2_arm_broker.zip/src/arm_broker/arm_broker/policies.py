"""Cola con politicas (Python puro, sin ROS): fifo | priority | aging | rr."""
import threading
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Entry:
    seq: int
    client_id: str
    priority: int                # 0 = mas alta
    t_enq: float                 # monotonic
    q: list
    t_wall: float = 0.0
    gh: Any = None
    t_start: float = 0.0
    done: threading.Event = field(default_factory=threading.Event)
    outcome: str = ''
    message: str = ''
    final_q: list = field(default_factory=list)


class Scheduler:
    def __init__(self, policy='fifo', aging_rate=0.05):
        assert policy in ('fifo', 'priority', 'aging', 'rr'), f'politica invalida: {policy}'
        self.policy, self.aging_rate, self.items, self._last = policy, aging_rate, [], None

    def __len__(self):
        return len(self.items)

    def push(self, e):
        self.items.append(e)

    def pop(self, now):
        if not self.items:
            return None
        if self.policy == 'rr':   # siguiente cliente en orden alfabetico, FIFO dentro del cliente
            names = sorted({e.client_id for e in self.items})
            self._last = next((c for c in names if self._last is None or c > self._last), names[0])
            e = min((e for e in self.items if e.client_id == self._last), key=lambda e: e.seq)
        else:
            key = {'fifo': lambda e: (0, e.seq),
                   'priority': lambda e: (e.priority, e.seq),
                   'aging': lambda e: (e.priority - self.aging_rate * (now - e.t_enq), e.seq),
                   }[self.policy]
            e = min(self.items, key=key)
        self.items.remove(e)
        return e
