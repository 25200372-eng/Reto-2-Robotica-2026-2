"""Portero: validacion barata e inmediata usando la FK del Item 1 (kinematics.py)."""
from dataclasses import dataclass, field

import numpy as np

from .kinematics import fk

D = np.pi / 180.0


@dataclass
class Limits:
    # Limites articulares del myCobot 280 (rad); verificar con el robot real.
    q_min: np.ndarray = field(default_factory=lambda: np.array([-168, -135, -150, -145, -165, -180]) * D)
    q_max: np.ndarray = field(default_factory=lambda: np.array([168, 135, 150, 145, 165, 180]) * D)
    max_step: float = 1.5     # rad por articulacion respecto a la pose de referencia
    r_max: float = 280.0      # mm, alcance horizontal
    z_min: float = 10.0       # mm, por debajo choca con la mesa
    z_max: float = 450.0


def validate(q, ref, lim):
    """Devuelve (ok, codigo, motivo_legible)."""
    q = np.asarray(q, float)
    if q.shape != (6,):
        return False, 'BAD_LENGTH', f'q debe tener 6 articulaciones, llegaron {q.size}'
    if not np.isfinite(q).all():
        return False, 'NOT_FINITE', 'q contiene NaN o infinito'
    bad = np.flatnonzero((q < lim.q_min) | (q > lim.q_max))
    if bad.size:
        j = bad[0]
        return False, 'JOINT_LIMIT', (f'J{j + 1}={q[j] / D:.1f} deg fuera de '
                                      f'[{lim.q_min[j] / D:.0f}, {lim.q_max[j] / D:.0f}] deg')
    step = np.abs(q - np.asarray(ref, float))
    j = int(step.argmax())
    if step[j] > lim.max_step:
        return False, 'STEP_TOO_LARGE', f'paso en J{j + 1} = {step[j] / D:.1f} deg, maximo {lim.max_step / D:.1f} deg'
    x, y, z = fk(q)[:3, 3]
    r = float(np.hypot(x, y))
    if r > lim.r_max or not lim.z_min <= z <= lim.z_max:
        return False, 'WORKSPACE', (f'efector en r={r:.0f} mm, z={z:.0f} mm; permitido '
                                    f'r<={lim.r_max:.0f}, z en [{lim.z_min:.0f}, {lim.z_max:.0f}] mm')
    return True, 'OK', 'admitido'
