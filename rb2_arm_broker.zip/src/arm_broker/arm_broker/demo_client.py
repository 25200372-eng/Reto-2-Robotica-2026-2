"""Cliente de ejemplo: pide turno al broker, nunca publica en /joint_states.

Terminal:  ros2 run arm_broker demo_client --client ana --priority 1 --n 3
Notebook:  rclpy.init(); c = DemoClient('ana', 1); c.move([0.3, -0.4, 0.2, 0, 0.3, 0])
"""
import argparse

import numpy as np
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from arm_broker_interfaces.action import MoveJoints


class DemoClient(Node):
    def __init__(self, client_id, priority=1):
        super().__init__(f'cliente_{client_id}')
        self.client_id, self.priority = client_id, int(priority)
        self._ac = ActionClient(self, MoveJoints, '/arm/move_joints')

    def move(self, q, timeout=300.0):
        """Pide un movimiento (q en rad). Devuelve el resultado, o None si fue rechazado."""
        self._ac.wait_for_server()
        fut = self._ac.send_goal_async(MoveJoints.Goal(
            client_id=self.client_id, priority=self.priority, q=[float(x) for x in q]))
        rclpy.spin_until_future_complete(self, fut)
        if not fut.result().accepted:
            self.get_logger().warn('rechazado (motivo en /arm/rejections y rechazos.csv)')
            return None
        rf = fut.result().get_result_async()
        rclpy.spin_until_future_complete(self, rf, timeout_sec=timeout)
        return rf.result().result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--client', default='cliente1')
    ap.add_argument('--priority', type=int, default=1)
    ap.add_argument('--n', type=int, default=3)
    a = ap.parse_args()
    rclpy.init()
    c = DemoClient(a.client, a.priority)
    for _ in range(a.n):
        r = c.move(np.random.uniform(-0.6, 0.6, 6))
        c.get_logger().info(f'resultado: {None if r is None else (r.success, r.message)}')
    rclpy.shutdown()


if __name__ == '__main__':
    main()
