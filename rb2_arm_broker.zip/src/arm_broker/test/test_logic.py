import numpy as np
from arm_broker.admission import Limits, validate
from arm_broker.policies import Entry, Scheduler


def order(policy, entries, now=0.0, **kw):
    s = Scheduler(policy, **kw)
    for e in entries:
        s.push(e)
    return [s.pop(now).seq for _ in entries]


def mk(seq, client, prio, t=0.0):
    return Entry(seq, client, prio, t, [0] * 6)


def test_fifo():
    assert order('fifo', [mk(1, 'a', 2), mk(2, 'b', 0), mk(3, 'c', 1)]) == [1, 2, 3]


def test_priority():
    assert order('priority', [mk(1, 'a', 2), mk(2, 'b', 0), mk(3, 'c', 1)]) == [2, 3, 1]


def test_aging_evita_inanicion():
    assert order('aging', [mk(1, 'a', 2, 0.0), mk(2, 'b', 0, 100.0)], 100.0) == [1, 2]
    assert order('priority', [mk(1, 'a', 2, 0.0), mk(2, 'b', 0, 100.0)], 100.0) == [2, 1]


def test_round_robin():
    es = [mk(1, 'a', 1), mk(2, 'a', 1), mk(3, 'a', 1), mk(4, 'b', 1), mk(5, 'c', 1)]
    assert order('rr', es) == [1, 4, 5, 2, 3]


def test_admision():
    lim, ref = Limits(), np.zeros(6)
    A = [0.5, -0.5, 0.3, 0, 0.4, 0]
    assert validate(A, ref, lim)[0]
    assert validate([0.1] * 5, ref, lim)[1] == 'BAD_LENGTH'
    assert validate([float('nan'), 0, 0, 0, 0, 0], ref, lim)[1] == 'NOT_FINITE'
    assert validate([4, 0, 0, 0, 0, 0], ref, lim)[1] == 'JOINT_LIMIT'
    assert validate([2.5, 0, 0, 0, 0, 0], np.array(A), lim)[1] == 'STEP_TOO_LARGE'
    assert validate(A, ref, Limits(z_min=500))[1] == 'WORKSPACE'
