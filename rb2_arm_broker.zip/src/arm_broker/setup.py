from setuptools import setup

package_name = 'arm_broker'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Equipo RB-2',
    maintainer_email='equipo@esan.edu.pe',
    description='Broker de acceso exclusivo al JetCobot',
    license='MIT',
    entry_points={
        'console_scripts': [
            'arm_broker = arm_broker.broker_node:main',
            'demo_client = arm_broker.demo_client:main',
        ],
    },
)
